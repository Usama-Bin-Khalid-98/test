<?php

use Illuminate\Database\Seeder;

class AccreditationMeetingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
