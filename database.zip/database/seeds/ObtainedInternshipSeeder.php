<?php

use Illuminate\Database\Seeder;

class ObtainedInternshipSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
