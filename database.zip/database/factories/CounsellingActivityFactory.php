<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CounsellingActivity;
use Faker\Generator as Faker;

$factory->define(CounsellingActivity::class, function (Faker $faker) {
    return [
        //
    ];
});
