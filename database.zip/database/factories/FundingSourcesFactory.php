<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\FundingSources;
use Faker\Generator as Faker;

$factory->define(FundingSources::class, function (Faker $faker) {
    return [
        //
    ];
});
