<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\StatutoryBody;
use Faker\Generator as Faker;

$factory->define(StatutoryBody::class, function (Faker $faker) {
    return [
        //
    ];
});
