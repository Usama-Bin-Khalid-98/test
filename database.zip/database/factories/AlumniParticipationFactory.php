<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AlumniParticipation;
use Faker\Generator as Faker;

$factory->define(AlumniParticipation::class, function (Faker $faker) {
    return [
        //
    ];
});
