<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\ParentInstitution;
use Faker\Generator as Faker;

$factory->define(ParentInstitution::class, function (Faker $faker) {
    return [
        //
    ];
});
