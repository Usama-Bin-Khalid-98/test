<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\social_responsibility\InternalCommunity;
use Faker\Generator as Faker;

$factory->define(InternalCommunity::class, function (Faker $faker) {
    return [
        //
    ];
});
