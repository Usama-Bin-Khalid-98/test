<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\Affiliation;
use Faker\Generator as Faker;

$factory->define(Affiliation::class, function (Faker $faker) {
    return [
        //
    ];
});
