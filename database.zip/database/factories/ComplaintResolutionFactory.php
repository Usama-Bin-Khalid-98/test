<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\social_responsibility\ComplaintResolution;
use Faker\Generator as Faker;

$factory->define(ComplaintResolution::class, function (Faker $faker) {
    return [
        //
    ];
});
