<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\facility\SupportStaff;
use Faker\Generator as Faker;

$factory->define(SupportStaff::class, function (Faker $faker) {
    return [
        //
    ];
});
