<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Research\Conference;
use Faker\Generator as Faker;

$factory->define(Conference::class, function (Faker $faker) {
    return [
        //
    ];
});
