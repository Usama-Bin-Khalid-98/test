<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\FacultyDegree;
use Faker\Generator as Faker;

$factory->define(FacultyDegree::class, function (Faker $faker) {
    return [
        //
    ];
});
