<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\EligibilityScreening\EligibilityScreening;
use Faker\Generator as Faker;

$factory->define(EligibilityScreening::class, function (Faker $faker) {
    return [
        //
    ];
});
