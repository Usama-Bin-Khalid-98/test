<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Facility\BusinessSchoolFacility;
use Faker\Generator as Faker;

$factory->define(BusinessSchoolFacility::class, function (Faker $faker) {
    return [
        //
    ];
});
