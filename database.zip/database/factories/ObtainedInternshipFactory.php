<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\External_Linkages\ObtainedInternship;
use Faker\Generator as Faker;

$factory->define(ObtainedInternship::class, function (Faker $faker) {
    return [
        //
    ];
});
