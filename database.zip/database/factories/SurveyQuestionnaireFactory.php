<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\SurveyQuestionnaire;
use Faker\Generator as Faker;

$factory->define(SurveyQuestionnaire::class, function (Faker $faker) {
    return [
        //
    ];
});
