<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PersonalGrooming;
use Faker\Generator as Faker;

$factory->define(PersonalGrooming::class, function (Faker $faker) {
    return [
        //
    ];
});
