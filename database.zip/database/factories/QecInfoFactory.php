<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\facility\QecInfo;
use Faker\Generator as Faker;

$factory->define(QecInfo::class, function (Faker $faker) {
    return [
        //
    ];
});
