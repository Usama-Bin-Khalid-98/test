<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ExtraActivities;
use Faker\Generator as Faker;

$factory->define(ExtraActivities::class, function (Faker $faker) {
    return [
        //
    ];
});
