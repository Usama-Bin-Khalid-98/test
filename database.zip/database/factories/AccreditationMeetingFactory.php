<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\AccreditationAC\AccreditationMeeting;
use Faker\Generator as Faker;

$factory->define(AccreditationMeeting::class, function (Faker $faker) {
    return [
        //
    ];
});
