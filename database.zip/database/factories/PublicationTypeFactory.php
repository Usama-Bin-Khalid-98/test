<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PublicationType;
use Faker\Generator as Faker;

$factory->define(PublicationType::class, function (Faker $faker) {
    return [
        //
    ];
});
