<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Faculty\Stability;
use Faker\Generator as Faker;

$factory->define(Stability::class, function (Faker $faker) {
    return [
        //
    ];
});
