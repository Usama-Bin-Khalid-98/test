<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Common\FypRequirement;
use Faker\Generator as Faker;

$factory->define(FypRequirement::class, function (Faker $faker) {
    return [
        //
    ];
});
