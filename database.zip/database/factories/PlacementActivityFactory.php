<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\External_Linkages\PlacementActivity;
use Faker\Generator as Faker;

$factory->define(PlacementActivity::class, function (Faker $faker) {
    return [
        //
    ];
});
