<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Reasearch\FacultyDevelopment;
use Faker\Generator as Faker;

$factory->define(FacultyDevelopment::class, function (Faker $faker) {
    return [
        //
    ];
});
