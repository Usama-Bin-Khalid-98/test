<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\facility\FinancialRisk;
use Faker\Generator as Faker;

$factory->define(FinancialRisk::class, function (Faker $faker) {
    return [
        //
    ];
});
