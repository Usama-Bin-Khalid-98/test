<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CharterType;
use Faker\Generator as Faker;

$factory->define(CharterType::class, function (Faker $faker) {
    return [
        //
    ];
});
