<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ClassSize;
use Faker\Generator as Faker;

$factory->define(ClassSize::class, function (Faker $faker) {
    return [
        //
    ];
});
