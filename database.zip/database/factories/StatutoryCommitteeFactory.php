<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\StatutoryCommittee;
use Faker\Generator as Faker;

$factory->define(StatutoryCommittee::class, function (Faker $faker) {
    return [
        //
    ];
});
