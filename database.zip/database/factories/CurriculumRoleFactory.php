<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Research\CurriculumRole;
use Faker\Generator as Faker;

$factory->define(CurriculumRole::class, function (Faker $faker) {
    return [
        //
    ];
});
