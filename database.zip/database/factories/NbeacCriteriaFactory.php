<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\NbeacCriteria;
use Faker\Generator as Faker;

$factory->define(NbeacCriteria::class, function (Faker $faker) {
    return [
        //
    ];
});
