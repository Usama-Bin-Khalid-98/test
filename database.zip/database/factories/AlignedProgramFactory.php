<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Carriculum\AlignedProgram;
use Faker\Generator as Faker;

$factory->define(AlignedProgram::class, function (Faker $faker) {
    return [
        //
    ];
});
