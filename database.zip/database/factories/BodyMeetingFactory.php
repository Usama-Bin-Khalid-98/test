<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\External_Linkages\BodyMeeting;
use Faker\Generator as Faker;

$factory->define(BodyMeeting::class, function (Faker $faker) {
    return [
        //
    ];
});
