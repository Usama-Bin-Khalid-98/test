<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\ContactInfo;
use Faker\Generator as Faker;

$factory->define(ContactInfo::class, function (Faker $faker) {
    return [
        //
    ];
});
