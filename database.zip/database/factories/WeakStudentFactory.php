<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\WeakStudent;
use Faker\Generator as Faker;

$factory->define(WeakStudent::class, function (Faker $faker) {
    return [
        //
    ];
});
