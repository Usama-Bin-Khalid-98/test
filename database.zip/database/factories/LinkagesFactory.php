<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\External_Linkages\Linkages;
use Faker\Generator as Faker;

$factory->define(Linkages::class, function (Faker $faker) {
    return [
        //
    ];
});
