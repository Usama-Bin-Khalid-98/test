<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StudentsGraduated;
use Faker\Generator as Faker;

$factory->define(StudentsGraduated::class, function (Faker $faker) {
    return [
        //
    ];
});
