<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Common\PaymentMethod;
use Faker\Generator as Faker;

$factory->define(PaymentMethod::class, function (Faker $faker) {
    return [
        //
    ];
});
