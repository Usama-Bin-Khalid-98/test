<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Mentoring\MentoringReport;
use Faker\Generator as Faker;

$factory->define(MentoringReport::class, function (Faker $faker) {
    return [
        //
    ];
});
