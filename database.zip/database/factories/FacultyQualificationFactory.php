<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Common\FacultyQualification;
use Faker\Generator as Faker;

$factory->define(FacultyQualification::class, function (Faker $faker) {
    return [
        //
    ];
});
