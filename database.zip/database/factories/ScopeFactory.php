<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\Scope;
use Faker\Generator as Faker;

$factory->define(Scope::class, function (Faker $faker) {
    return [
        //
    ];
});
