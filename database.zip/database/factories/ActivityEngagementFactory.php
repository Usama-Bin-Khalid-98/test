<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ActivityEngagement;
use Faker\Generator as Faker;

$factory->define(ActivityEngagement::class, function (Faker $faker) {
    return [
        //
    ];
});
