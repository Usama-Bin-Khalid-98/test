<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Research\ResearchFunding;
use Faker\Generator as Faker;

$factory->define(ResearchFunding::class, function (Faker $faker) {
    return [
        //
    ];
});
