<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\External_Linkages\FacultyExchange;
use Faker\Generator as Faker;

$factory->define(FacultyExchange::class, function (Faker $faker) {
    return [
        //
    ];
});
