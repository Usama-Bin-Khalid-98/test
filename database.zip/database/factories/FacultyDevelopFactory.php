<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Faculty\FacultyDevelop;
use Faker\Generator as Faker;

$factory->define(FacultyDevelop::class, function (Faker $faker) {
    return [
        //
    ];
});
