<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Carriculum\CourseDetail;
use Faker\Generator as Faker;

$factory->define(CourseDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
