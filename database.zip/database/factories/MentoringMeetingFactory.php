<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\MentoringMeeting;
use Faker\Generator as Faker;

$factory->define(MentoringMeeting::class, function (Faker $faker) {
    return [
        //
    ];
});
