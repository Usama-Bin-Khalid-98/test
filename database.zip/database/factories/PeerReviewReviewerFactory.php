<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\PeerReivew\PeerReviewReviewer;
use Faker\Generator as Faker;

$factory->define(PeerReviewReviewer::class, function (Faker $faker) {
    return [
        //
    ];
});
