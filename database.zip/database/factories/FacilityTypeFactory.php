<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Facility\FacilityType;
use Faker\Generator as Faker;

$factory->define(FacilityType::class, function (Faker $faker) {
    return [
        //
    ];
});
