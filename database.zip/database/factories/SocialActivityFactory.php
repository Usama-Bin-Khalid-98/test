<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\social_responsibility\SocialActivity;
use Faker\Generator as Faker;

$factory->define(SocialActivity::class, function (Faker $faker) {
    return [
        //
    ];
});
