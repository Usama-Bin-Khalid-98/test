<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StudentTransfer;
use Faker\Generator as Faker;

$factory->define(StudentTransfer::class, function (Faker $faker) {
    return [
        //
    ];
});
