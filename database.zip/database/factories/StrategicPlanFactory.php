<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\StrategicPlan;
use Faker\Generator as Faker;

$factory->define(StrategicPlan::class, function (Faker $faker) {
    return [
        //
    ];
});
