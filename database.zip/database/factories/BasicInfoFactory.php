<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\BasicInfo;
use Faker\Generator as Faker;

$factory->define(BasicInfo::class, function (Faker $faker) {
    return [
        //
    ];
});
