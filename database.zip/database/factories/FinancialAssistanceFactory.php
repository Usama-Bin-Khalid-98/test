<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\FinancialAssistance;
use Faker\Generator as Faker;

$factory->define(FinancialAssistance::class, function (Faker $faker) {
    return [
        //
    ];
});
