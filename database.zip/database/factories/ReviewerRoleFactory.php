<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Common\ReviewerRole;
use Faker\Generator as Faker;

$factory->define(ReviewerRole::class, function (Faker $faker) {
    return [
        //
    ];
});
