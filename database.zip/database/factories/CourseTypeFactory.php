<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Common\CourseType;
use Faker\Generator as Faker;

$factory->define(CourseType::class, function (Faker $faker) {
    return [
        //
    ];
});
