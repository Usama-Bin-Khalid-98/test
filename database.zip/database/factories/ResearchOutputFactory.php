<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Research\ResearchOutput;
use Faker\Generator as Faker;

$factory->define(ResearchOutput::class, function (Faker $faker) {
    return [
        //
    ];
});
