<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\social_responsibility\WelfareProgram;
use Faker\Generator as Faker;

$factory->define(WelfareProgram::class, function (Faker $faker) {
    return [
        //
    ];
});
