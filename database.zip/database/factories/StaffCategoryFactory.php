<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\facility\StaffCategory;
use Faker\Generator as Faker;

$factory->define(StaffCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
