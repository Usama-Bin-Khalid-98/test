<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\EligibilityScreening\EligibilityReport;
use Faker\Generator as Faker;

$factory->define(EligibilityReport::class, function (Faker $faker) {
    return [
        //
    ];
});
