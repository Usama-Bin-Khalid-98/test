<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\SourcesFunding;
use Faker\Generator as Faker;

$factory->define(SourcesFunding::class, function (Faker $faker) {
    return [
        //
    ];
});
