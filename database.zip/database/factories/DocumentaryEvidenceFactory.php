<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DocumentaryEvidence;
use Faker\Generator as Faker;

$factory->define(DocumentaryEvidence::class, function (Faker $faker) {
    return [
        //
    ];
});
