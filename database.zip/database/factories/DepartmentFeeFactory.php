<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DepartmentFee;
use Faker\Generator as Faker;

$factory->define(DepartmentFee::class, function (Faker $faker) {
    return [
        //
    ];
});
