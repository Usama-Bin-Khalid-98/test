<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DropoutPercentage;
use Faker\Generator as Faker;

$factory->define(DropoutPercentage::class, function (Faker $faker) {
    return [
        //
    ];
});
