<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AlumniMembership;
use Faker\Generator as Faker;

$factory->define(AlumniMembership::class, function (Faker $faker) {
    return [
        //
    ];
});
