<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\social_responsibility\ProjectDetail;
use Faker\Generator as Faker;

$factory->define(ProjectDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
