<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\ProgramPortfolio;
use Faker\Generator as Faker;

$factory->define(ProgramPortfolio::class, function (Faker $faker) {
    return [
        //
    ];
});
