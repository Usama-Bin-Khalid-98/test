<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\social_responsibility\FormalRelationship;
use Faker\Generator as Faker;

$factory->define(FormalRelationship::class, function (Faker $faker) {
    return [
        //
    ];
});
