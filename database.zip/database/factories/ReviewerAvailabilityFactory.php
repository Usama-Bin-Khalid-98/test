<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\EligibilityScreening\ReviewerAvailability;
use Faker\Generator as Faker;

$factory->define(ReviewerAvailability::class, function (Faker $faker) {
    return [
        //
    ];
});
