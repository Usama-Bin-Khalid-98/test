<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Faculty\FacultyPromotion;
use Faker\Generator as Faker;

$factory->define(FacultyPromotion::class, function (Faker $faker) {
    return [
        //
    ];
});
