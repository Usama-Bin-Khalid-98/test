<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\MentoringInvoice;
use Faker\Generator as Faker;

$factory->define(MentoringInvoice::class, function (Faker $faker) {
    return [
        //
    ];
});
