<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\PeerReview\InstituteFeedback;
use Faker\Generator as Faker;

$factory->define(InstituteFeedback::class, function (Faker $faker) {
    return [
        //
    ];
});
