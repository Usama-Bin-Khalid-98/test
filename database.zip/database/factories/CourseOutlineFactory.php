<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Carriculum\CourseOutline;
use Faker\Generator as Faker;

$factory->define(CourseOutline::class, function (Faker $faker) {
    return [
        //
    ];
});
