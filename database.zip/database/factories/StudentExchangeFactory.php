<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\External_Linkages\StudentExchange;
use Faker\Generator as Faker;

$factory->define(StudentExchange::class, function (Faker $faker) {
    return [
        //
    ];
});
