<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Common\EligibilityCriteria;
use Faker\Generator as Faker;

$factory->define(EligibilityCriteria::class, function (Faker $faker) {
    return [
        //
    ];
});
