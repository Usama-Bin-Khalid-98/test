<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Common\PublicationCategory;
use Faker\Generator as Faker;

$factory->define(PublicationCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
