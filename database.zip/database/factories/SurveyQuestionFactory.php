<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SurveyQuestion;
use Faker\Generator as Faker;

$factory->define(SurveyQuestion::class, function (Faker $faker) {
    return [
        //
    ];
});
