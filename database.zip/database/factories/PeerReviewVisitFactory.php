<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\PeerReview\PeerReviewVisit;
use Faker\Generator as Faker;

$factory->define(PeerReviewVisit::class, function (Faker $faker) {
    return [
        //
    ];
});
