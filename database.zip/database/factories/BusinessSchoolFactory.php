<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\BusinessSchool;
use Faker\Generator as Faker;

$factory->define(BusinessSchool::class, function (Faker $faker) {
    return [
        //
    ];
});
