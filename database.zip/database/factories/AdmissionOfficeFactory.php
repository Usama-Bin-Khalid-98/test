<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AdmissionOffice;
use Faker\Generator as Faker;

$factory->define(AdmissionOffice::class, function (Faker $faker) {
    return [
        //
    ];
});
