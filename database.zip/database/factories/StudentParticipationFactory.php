<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StudentParticipation;
use Faker\Generator as Faker;

$factory->define(StudentParticipation::class, function (Faker $faker) {
    return [
        //
    ];
});
