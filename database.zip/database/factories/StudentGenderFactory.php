<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StudentGender;
use Faker\Generator as Faker;

$factory->define(StudentGender::class, function (Faker $faker) {
    return [
        //
    ];
});
