<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Faculty\WorkLoad;
use Faker\Generator as Faker;

$factory->define(WorkLoad::class, function (Faker $faker) {
    return [
        //
    ];
});
