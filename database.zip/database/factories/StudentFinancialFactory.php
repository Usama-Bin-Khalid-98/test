<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StudentFinancial;
use Faker\Generator as Faker;

$factory->define(StudentFinancial::class, function (Faker $faker) {
    return [
        //
    ];
});
