<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\BudgetaryInfo;
use Faker\Generator as Faker;

$factory->define(BudgetaryInfo::class, function (Faker $faker) {
    return [
        //
    ];
});
