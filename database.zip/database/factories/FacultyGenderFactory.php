<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Faculty\FacultyGender;
use Faker\Generator as Faker;

$factory->define(FacultyGender::class, function (Faker $faker) {
    return [
        //
    ];
});
