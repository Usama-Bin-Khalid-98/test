<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\social_responsibility\StudentClub;
use Faker\Generator as Faker;

$factory->define(StudentClub::class, function (Faker $faker) {
    return [
        //
    ];
});
