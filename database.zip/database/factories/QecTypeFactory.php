<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\facility\QecType;
use Faker\Generator as Faker;

$factory->define(QecType::class, function (Faker $faker) {
    return [
        //
    ];
});
