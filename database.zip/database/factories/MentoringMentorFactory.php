<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\MentoringMentor;
use Faker\Generator as Faker;

$factory->define(MentoringMentor::class, function (Faker $faker) {
    return [
        //
    ];
});
