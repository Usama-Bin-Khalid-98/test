<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\External_Linkages\PlacementOffice;
use Faker\Generator as Faker;

$factory->define(PlacementOffice::class, function (Faker $faker) {
    return [
        //
    ];
});
