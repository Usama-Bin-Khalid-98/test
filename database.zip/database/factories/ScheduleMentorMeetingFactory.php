<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Mentoring\ScheduleMentorMeeting;
use Faker\Generator as Faker;

$factory->define(ScheduleMentorMeeting::class, function (Faker $faker) {
    return [
        //
    ];
});
