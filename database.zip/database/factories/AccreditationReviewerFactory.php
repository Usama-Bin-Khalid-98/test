<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\AccreditationAC\AccreditationReviewer;
use Faker\Generator as Faker;

$factory->define(AccreditationReviewer::class, function (Faker $faker) {
    return [
        //
    ];
});
