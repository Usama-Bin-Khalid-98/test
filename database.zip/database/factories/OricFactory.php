<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Research\Oric;
use Faker\Generator as Faker;

$factory->define(Oric::class, function (Faker $faker) {
    return [
        //
    ];
});
