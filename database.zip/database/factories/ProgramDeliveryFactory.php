<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Carriculum\ProgramDelivery;
use Faker\Generator as Faker;

$factory->define(ProgramDelivery::class, function (Faker $faker) {
    return [
        //
    ];
});
