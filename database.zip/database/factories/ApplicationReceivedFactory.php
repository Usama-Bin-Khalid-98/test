<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StrategicManagement\ApplicationReceived;
use Faker\Generator as Faker;

$factory->define(ApplicationReceived::class, function (Faker $faker) {
    return [
        //
    ];
});
