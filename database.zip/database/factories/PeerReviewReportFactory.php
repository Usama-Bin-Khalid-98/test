<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\PeerReview\PeerReviewReport;
use Faker\Generator as Faker;

$factory->define(PeerReviewReport::class, function (Faker $faker) {
    return [
        //
    ];
});
