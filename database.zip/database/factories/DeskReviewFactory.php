<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\DeskReview;
use Faker\Generator as Faker;

$factory->define(DeskReview::class, function (Faker $faker) {
    return [
        //
    ];
});
