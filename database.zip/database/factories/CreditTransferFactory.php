<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CreditTransfer;
use Faker\Generator as Faker;

$factory->define(CreditTransfer::class, function (Faker $faker) {
    return [
        //
    ];
});
