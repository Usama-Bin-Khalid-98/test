<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\AccreditationAC\ScheduleAccreditationAward;
use Faker\Generator as Faker;

$factory->define(ScheduleAccreditationAward::class, function (Faker $faker) {
    return [
        //
    ];
});
