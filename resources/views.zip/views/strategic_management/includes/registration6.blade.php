<br><p class="left">6.1	Provide complete financial information of the business school in Table.6.1 (Rupees in million). </p>
@include('strategic_management.includes.registration6_1b')

<br><p class="left">6.2	Provide information about different facilities of the business school in Table 6.2.</p>
@include('strategic_management.includes.registration6_2b')
