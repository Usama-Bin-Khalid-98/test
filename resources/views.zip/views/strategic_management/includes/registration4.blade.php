<br><p class="left">4.1	Provide information about core business school faculty : present aggregate numbers in Table 4.1.</p>

@include('strategic_management.includes.registration4_1')
 <br><p class="left">4.2	Provide information of faculty workload over the last two semesters in Table 4.2a and 4.2b. Attach faculty workload policy as Appendix-4A.</p>
@include('strategic_management.includes.4_2')

@include('strategic_management.includes.4_2b')
<br><p class="left">4.3	Provide data for Full Time Equivalent (FTE) for the permanent, regular and adjunct faculty of last year in Table 4.3a and Visiting Faculty Equivalent (VFE) of last year in table 4.3.b for the program under review.</p>
@include('strategic_management.includes.registration4_3')

@include('strategic_management.includes.registration4_3b')
<br><p class="left">4.4	Fill in data to calculate student to teacher ratio for last year of each program under review in Table 4.4.</p>
@include('strategic_management.includes.registration4_4')
<br><p class="left">4.5	Provide data on faculty stability in Table 4.5.</p>
@include('strategic_management.includes.registration4_5')
<br><p class="left">4.6	Provide data on the gender mix of the business school faculty in Table 4.6.</p>
@include('strategic_management.includes.4_6')
 