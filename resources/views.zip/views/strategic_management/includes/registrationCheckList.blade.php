
<div class="box-body table-responsive">
                            <table   class="table table-bordered table-striped ">
                                
                                <thead>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th colspan="2" >Attached (please tick the box)</th>
                                    <th>No. of pages  of the appendix</th>
                                    
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1.  Appendix-1A</td>
                                        <td>CV of the dean, head of school and focal person (max. four pages each)</td>
                                        <td>Yes</td>
                                        <td>No</td>
                                        <td></td>
                                        
                                    </tr>
                                    
                                    <tr>
                                        <td>2.  Appendix-1B</td>
                                        <td>Composition, name of committee members, role and functions of statutory bodies </td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>

                                    <tr>
                                        <td>3.  Appendix-1C</td>
                                        <td>Approved vision and mission statements of the university and business school with evidence of approval </td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>4.  Appendix-1D</td>
                                        <td>Approved strategic plan of the business school with evidence of approval </td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>5.  Appendix-1E</td>
                                        <td>Organogram of the business school and parent institution </td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>6.  Appendix-4A</td>
                                        <td>Faculty workload policy </td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>7.  Appendix-5A</td>
                                        <td>List of items mentioned in Table. using APA end-text referencing. </td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                   
                              
                                </tbody>
                                <tfoot></tfoot>
                              
                              

                            </table>
                        </div>