<div >                  <br><br>
                        <div class="center">
                            <h2 style="height: 150px;"><b>Contents</b></h2>
                        </div><br>
                        <div class="center" style="page-break-after: always;">
                        <ul style="list-style-type: none">
                            <li>Preface---------------------------------------------------------------------------------------------------------------------------2</li>
                            <li>Instructions for the application preparation---------------------------------------------------------------------------3</li>
                            <li>Undertaking--------------------------------------------------------------------------------------------------------------------4</li>
                            <li>Section 1: Strategic Management-----------------------------------------------------------------------------------------5</li>
                            <li>Section 2: Curriculum--------------------------------------------------------------------------------------------------------6</li>
                            <li>Section 3: Students-----------------------------------------------------------------------------------------------------------7</li>
                            <li>Section 4: Faculty-------------------------------------------------------------------------------------------------------------9</li>
                            <li>Section 5: Research & Development------------------------------------------------------------------------------------11</li>
                            <li>Checklist of mandatory appendices with registration application---------------------------------------------15</li>
                        </ul>
                        </div>
                    </div> 
                    <div class="row" style="position: relative;width: 100%">
                        <div style="position: absolute;left: 50px;top:20px">
                            <img  width="100px" src="{{asset('/images/nbeacLogo.jpg')}}">
                        </div>
                        

                        <div style="position: absolute;right:50px;">
                            <img class="right" width="100px" src="{{asset('/images/HECLogo.jpg')}}">
                        </div>
                    
                    
                    </div>