<br>
<p class="left">3.1.	Provide the data on student enrolment  of the business school for the last three years in Table 3.1</p>
@include('strategic_management.includes.registration3_1')
<br>
<p class="left">3.2.	State the number of students who have graduated over the past three years for each program under review in Table 3.2.   </p>
@include('strategic_management.includes.registration3_2')
<br>
<p class="left">3.3.	State the current gender wise break down of students in each program under review in Table 3.3.</p>
@include('strategic_management.includes.registration3_3')
