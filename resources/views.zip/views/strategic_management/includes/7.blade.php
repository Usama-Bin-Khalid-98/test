<br><h1 class="center">7. Resources</h1>
<p class="left">7.1.	Provide financial information of the business school in Table.7.1 (in PKR millions). Attach the relevant policy to manage and plan financial resources as Appendix-7A.</p>
@include('strategic_management.includes.7_1')
<br><p class="left">7.2.	Provide data on financial risks along with remedial measures in Table 7.2.</p>
@include('strategic_management.includes.7_2')
<br><p class="left">7.3.	Provide data of staff of various offices in Table 7.3.</p>
@include('strategic_management.includes.7_3')
<br><p class="left">7.4.	Provide basic information of Quality Enhancement Cell (QEC) in Table 7.4. Attach policy for enhancing the quality function of education delivery as Appendix-7B.</p>
@include('strategic_management.includes.7_4')
<br><p class="left">7.5.	Provide information about different facilities of the business school in Table 7.5.</p>
@include('strategic_management.includes.7_5')
<hr>
<p class="left">19.	Income generated through various trainings and workshops conducted by the business school.</p>
<p class="left">20.	Describe concisely not exceeding 100 words.</p>
