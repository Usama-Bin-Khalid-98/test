<br><p class="left">5.1	Provide a summary of research output  of business school in last three academic years in Table.5.1. Attach a complete list of items mentioned in the table using APA end-text referencing along with clearly mentioning type of each item as impact factor or HEC category, as Appendix-5A.</p>
@include('strategic_management.includes.registration5_1b')
 