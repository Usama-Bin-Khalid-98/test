<br><h1 class="center">6. Social Responsibility</h1>
<p class="left">6.1	Provide data on student societies/clubs in Table 6.1.</p>
@include('strategic_management.includes.6_1')
<br><p class="left">6.2	List social initiatives  carried out by the business school during the last three years in Table 6.2. Attach policy on community development and social responsibility as Appendix-6A.</p>
@include('strategic_management.includes.6_2')
<br><p class="left">6.3	Enlist activities aimed at environmental protection and sustainability in Table 6.4. Attach policy on environmental protection as Appendix-6B.</p>
@include('strategic_management.includes.6_3')
<br><p class="left">6.4	Provide a list of associations or MOUs with organizations or institutes (NGOs / Public / Private) extending CSR activities in Table 6.3.</p>
@include('strategic_management.includes.6_4')
<br><p class="left">6.5	Attach the business school’s code of moral principles and ethics applicable to faculty, students and staff as Appendix-6C. Provide data on complaint resolution in Table 6.5. </p>
@include('strategic_management.includes.6_5')
<br><p class="left">6.6	Provide data on internal community welfare programs in Table 6.6. Attach policy on internal community welfare as Appendix-6D.</p>
@include('strategic_management.includes.6_6')
<p class="left">6.7	Attach documentary evidence for surveys or any other mechanism applied to assess the impact of social activities carried out by the business school during last three years.</p>
<hr><p class="left">18.	This includes activities such as tree plantation campaign, blood donation. </p>
