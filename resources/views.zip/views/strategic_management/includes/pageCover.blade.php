                    <style>
                        .centerme{ text-align: center;}
                    </style>
                    <p class="centerme" class="left_25">Name of University: ________________________________________________________</p>
                    <p class="centerme" class="left_25">Name of Business School: ___________________________________________________</p>
                    <p class="centerme" class="left_25">Program(s) for Review:  ______________________________________________________</p>
                    <p class="centerme" class="left_25">Submission dates:  __________________________________________________________</p>
                    <br /><br /><br /><br /><br /><br /><br /><br />
                    <div class="center"><h1><b>Registration</b></h1></div>
                    <div class="center"><h1><b>Application</b></h1></div>
                    <h5 style="text-align: center;height: 200px;"><b>NBEAC</b></h5><br><hr>
                    <p class="center">The registration application is to be completed by the business school seeking for accreditation under </p><p class="center">National Business Education Accreditation Council (NBEAC) of the Higher Education Commission, Pakistan</p>
                    <br>
                    <div class="row center" style="page-break-after: always;position: relative;width: 100%;">
                        <div style="position: absolute;left: 35%;top:20px">
                            <img src="{{asset('/images/nbeacLogo.jpg')}}" width="100px">
                        </div>
                        <div style="position: absolute;left:50%;">
                            <img src="{{asset('/images/HECLogo.jpg')}}" width="100px">
                        </div>
                        
                    </div><br><br><br><br>
