					@include('strategic_management.includes.1_1')
					<br>
					<p class="left">1.2. Provide scope of accreditation in Table 1.2.</p>
                    @include('strategic_management.includes.1_2')
                    <br><p class="left">1.3.	Provide contact information in the Table 1.3. Furthermore, attach CVs of the dean, head of the business school, and focal person as Appendix-1A.</p>
                    @include('strategic_management.includes.1_3')
                    <br><p class="left">1.4.	Provide information about the various statutory bodies in the Table 1.4. Also attach documentary information about the composition, name of members, role and functions of each statutory body as Appendix-1B. </p>
                    @include('strategic_management.includes.1_4')
                    <br><p class="left">1.5.	Provide details in Table 1.5 about the names, designations and affiliations of all external (academic and corporate), national or international members in each of the statutory bodies mentioned above in Table 1.4.</p>
                    @include('strategic_management.includes.1_5')
                    <br><p class="left">1.6.	Provide budgetary information of the business school in the Table 1.6.</p>
                    @include('strategic_management.includes.1_6')
                    <br><p class="left">1.7.	State the vision and mission of the university and that of the business school. Describe the process of formation and approval of the vision and mission statements. Attached the relevant pages of the official documents as Appendix-1C.</p>
                    <p>1.8.	Provide the approved strategic plan including critical success factors and key performance indicators of the business school as Appendix-1D.  Fill in the required information on approval of the strategic plan in the Table 1.7.</p>
                   
                    @include('strategic_management.includes.registration1_7')