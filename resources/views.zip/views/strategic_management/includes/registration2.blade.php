<br><p class="left">2.1.	Provide the portfolio of the program(s) under review in Table 2.1.</p>
@include('strategic_management.includes.registration2_1')
<br><p class="left">2.2.	Provide data on entry requirements for each program under review in Table 2.2. </p>
@include('strategic_management.includes.registration2_2')
<br><p class="left">2.3.	Provide data on the applications received and student intake in the past three years for each program in Table 2.3.</p>
@include('strategic_management.includes.registration2_3')
<br><p class="left">2.4.	Enumerate the degree awarding criteria/requirements for each program under review in Table 2.4.</p>
@include('strategic_management.includes.registration2_4')

 
